package view;

public class Text2SpeechEditorView {

	public static void main(String[] args) {
		new gui();
	}
}
