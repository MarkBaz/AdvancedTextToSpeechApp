package output;
import java.util.ArrayList;
public interface DocumentWriter {
	public void write(ArrayList<String> array);
}
