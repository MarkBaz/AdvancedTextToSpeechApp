package commands;

//import java.awt.event.ActionListener;

public interface Prototype {
	public void clonee();
}
