package input;

import java.util.ArrayList;

public interface DocumentReader {
	public ArrayList<String> read();
}
