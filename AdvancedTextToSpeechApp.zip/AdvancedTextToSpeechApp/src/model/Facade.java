package model;

public interface Facade {
	
	public void play(String stringg);

	public void setVolume(float integ);

	public void setPitch(float pitchnum);

	public void setRate(float ratenm);
}
